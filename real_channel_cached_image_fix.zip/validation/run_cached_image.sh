#!/usr/bin/env bash
# Reuse the complete experiment image, without querying any registry or building.
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.."
if [[ $# -eq 0 || "${1:-}" == --help ]]; then
  cat <<'HELP'
在原实验目录使用本机已构建的镜像：
  bash validation/run_cached_image.sh --preset paper --shard-requests 4
恢复原有实验（参数从原 config.json 读取）：
  bash validation/run_cached_image.sh --resume artifacts/<原运行目录名>
此入口不 build、不 pull；必须已存在 moe-real-channel:cu124-v1。
HELP
  exit 0
fi
command -v docker >/dev/null || { echo '[cached FAILED] 找不到 docker。' >&2; exit 1; }
docker info >/dev/null
image=moe-real-channel:cu124-v1
if ! docker image inspect "$image" >/dev/null 2>&1; then
  echo "[cached FAILED] 本机缺少 ${image}；未执行构建或拉取。" >&2
  echo '执行 docker image ls --digests，确认原镜像是否仍有其他 tag，或从已保存的完整实验镜像 tar 执行 docker load -i <文件>。' >&2
  echo '如果本机确实没有完整实验镜像，需要先解决 docker.1ms.run 的 manifest 拉取问题；重复本命令不能生成缺失镜像。' >&2
  exit 1
fi
mkdir -p artifacts cache
echo "[cached] 使用本机 ${image}；不访问镜像仓库。"
exec docker run --pull=never --rm --init \
  --gpus "${GPU_REQUEST:-all}" --cap-add=SYS_ADMIN --shm-size=2g \
  -e "HOST_UID=$(id -u)" -e "HOST_GID=$(id -g)" \
  -v "$PWD:/workspace" "$image" "$@"
